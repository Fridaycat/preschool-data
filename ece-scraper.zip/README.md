# ECE Scraper

自動抓取台灣教育部幼兒園公開查詢網站資料，並儲存成 CSV 格式。
透過 GitHub Actions 定時自動更新。