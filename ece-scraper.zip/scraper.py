import requests
from bs4 import BeautifulSoup
import pandas as pd

url = "https://ap.ece.moe.edu.tw/webecems/pubSearch.aspx"

# 發送初始請求，取得 __VIEWSTATE 等欄位
session = requests.Session()
r = session.get(url)
soup = BeautifulSoup(r.text, 'html.parser')

data = {
    '__VIEWSTATE': soup.find('input', {'id': '__VIEWSTATE'})['value'],
    '__VIEWSTATEGENERATOR': soup.find('input', {'id': '__VIEWSTATEGENERATOR'})['value'],
    '__EVENTVALIDATION': soup.find('input', {'id': '__EVENTVALIDATION'})['value'],
    '__EVENTTARGET': 'ctl00$ContentPlaceHolder1$btnSearch',
    '__EVENTARGUMENT': '',
    'ctl00$ContentPlaceHolder1$ddlCity': '67',  # 台南市
    'ctl00$ContentPlaceHolder1$ddlTown': '',  # 全部行政區
    'ctl00$ContentPlaceHolder1$tbSchoolName': '',  # 關鍵字
}

# 送出查詢表單
r2 = session.post(url, data=data)
soup2 = BeautifulSoup(r2.text, 'html.parser')

# 擷取資料
rows = soup2.select("table#ctl00_ContentPlaceHolder1_gvSearch tr")[1:]
result = []

for row in rows:
    cols = row.find_all("td")
    if len(cols) >= 7:
        result.append({
            "幼兒園名字": cols[1].text.strip(),
            "地址": cols[3].text.strip(),
            "電話": cols[4].text.strip(),
            "核定人數": cols[6].text.strip()
        })

# 儲存成 CSV
df = pd.DataFrame(result)
df.to_csv("kindergartens.csv", index=False, encoding="utf-8-sig")
print("已儲存 kindergartens.csv")
