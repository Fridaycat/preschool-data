
import undetected_chromedriver as uc
from bs4 import BeautifulSoup
import time

def main():
    options = uc.ChromeOptions()
    options.add_argument("--headless")
    driver = uc.Chrome(options=options)
    
    try:
        driver.get("https://ap.ece.moe.edu.tw/webecems/pubSearch.aspx")
        time.sleep(3)  # Let JavaScript render

        soup = BeautifulSoup(driver.page_source, "html.parser")
        print(soup.title.text)
    finally:
        driver.quit()

if __name__ == "__main__":
    main()
